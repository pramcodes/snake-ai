import java.io.BufferedReader;
import java.util.Stack;
import java.io.IOException;
import java.io.InputStreamReader;
import za.ac.wits.snake.DevelopmentAgent;

public class MyAgent extends DevelopmentAgent {

    public static void main(String args[]) {
        MyAgent agent = new MyAgent();
        MyAgent.start(agent, args);
    }

    @Override
    public void run() {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {

            String initString = br.readLine();
            
            String[] temp = initString.split(" ");
            
            int nSnakes = Integer.parseInt(temp[0]);
            
            int numObstacles = 3;
            
            while (true) {
                String line = br.readLine();
                
                if (line.contains("Game Over")) {
                    break;
                }
                
                String apple1 = line;
                
                
                String[] Acoords = line.split(" ");
                int X = Integer.parseInt(Acoords[0]);
                int Y = Integer.parseInt(Acoords[1]);
                
                for (int j=0; j<numObstacles; j++) {
                	String obsLine = br.readLine();
                }

                
                int mySnakeNum = Integer.parseInt(br.readLine());
                int MiHeadX = 0, MiHeadY = 0, NextX = 0, NextY = 0;
                int dir = 0;
                

                for (int i = 0; i < nSnakes; i++) {
                	
                    String snakeLine = br.readLine();
                    if (i == mySnakeNum) {
                    	String[] Snakie = snakeLine.split(" ");
                    	String[] MiHead = Snakie[3].split(",");
                    	MiHeadX = Integer.parseInt( MiHead[0] );
                    	MiHeadY = Integer.parseInt( MiHead[1]  );
                    	String[] snakeNext = Snakie[4].split(",");
                    	NextX = Integer.parseInt(snakeNext[0]);
                    	NextY = Integer.parseInt(snakeNext[1]);
    	
                        if (MiHeadX == NextX) {
                            if (MiHeadY < NextY) 
                                dir = 0;
                            else if (MiHeadY > NextY) 
                                dir = 1;
                        }else if (MiHeadY == NextY) {
                            if (MiHeadX < NextX) 
                                dir = 2;
                            else if (MiHeadX > NextX) 
                                dir = 3;
                        }	
                    }
                }
                int move = 0;

                if (MiHeadX < X) 
                    move = 3;
                else if (MiHeadX > X) 
                    move = 2;
                else if (MiHeadY < Y) 
                    move = 1;
                else if (MiHeadY > Y) 
                    move = 0;
                
                if (move == 0 && dir == 1) 
                    move = 3;
                else if (move == 1 && dir == 0) 
                    move = 2;
                else if (move == 2 && dir == 3) 
                    move = 1;
                else if (move == 3 && dir == 2) 
                    move = 0;

                System.out.println(move);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}